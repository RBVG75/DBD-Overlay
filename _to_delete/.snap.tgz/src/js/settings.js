// Builds and wires the settings panel.

import {
  ANCHORS, BACKDROPS, DEFAULT_PANEL_ITEM, EMPHASIS, END_ACTIONS, FONT_FAMILIES,
  HOTKEY_ACTIONS, ITEM_SOURCES, PANEL_LAYOUTS, PANEL_STYLES, PANEL_TRANSITIONS,
  POINTER_TYPES, SCREEN_MODES, SOUNDS, STATS_TEMPLATES, STOPWATCH_STYLES, TEXT_FORMATS, THEMES,
  TIMER_PRESETS, TIMER_STYLES, TRACKER_KINDS,
  buildTemplate, normalizePanel, normalizeTimer, normalizeTracker,
} from './defaults.js';
import {
  buttonRow, colorField, el, group, hotkeyField, numberField, rangeField,
  selectField, textField, toggleField,
} from './controls.js';
import { createHotkeyCapture, formatHotkey } from './hotkeys.js';
import { mountPanel } from './panels.js';
import { formulaIsValid } from './stats.js';
import { createTimerView } from './timer-render.js';
import { deepClone as deepCopy, formatClock } from './utils.js';

const PAGES = [
  { id: 'general', label: 'General', icon: '◆' },
  { id: 'trackers', label: 'Contadores', icon: '⧉' },
  { id: 'panels', label: 'Paneles', icon: '▤' },
  { id: 'timers', label: 'Temporizadores', icon: '◍' },
  { id: 'stopwatch', label: 'Cronómetro', icon: '▣' },
  { id: 'crosshair', label: 'Mira', icon: '✛' },
  { id: 'scoreboard', label: 'Marcador', icon: '⊞' },
  { id: 'hotkeys', label: 'Atajos', icon: '⌘' },
];

function createPreview(container) {
  let view = null;
  let raf = null;
  let cfg = null;
  let t0 = 0;

  function stop() {
    if (raf) cancelAnimationFrame(raf);
    raf = null;
    if (view) view.destroy();
    view = null;
  }

  function loop() {
    const step = () => {
      const now = performance.now();
      // Compress the cycle so any duration animates in roughly eight seconds.
      const speed = Math.max(1, cfg.seconds / 8);
      const elapsedRaw = ((now - t0) / 1000) * speed;
      const cycle = elapsedRaw % (cfg.seconds * 1.12);
      const elapsed = Math.min(cfg.seconds, cycle);
      const remaining = Math.max(0, cfg.seconds - cycle);
      const p = cfg.direction === 'fill' ? elapsed / cfg.seconds : remaining / cfg.seconds;
      const phase = remaining <= cfg.danger_at ? 'danger' : remaining <= cfg.warn_at ? 'warning' : 'normal';
      const color = phase === 'danger' ? cfg.danger_color : phase === 'warning' ? cfg.warn_color : cfg.color;
      let text = '';
      if (cfg.text_format === 'percent') text = `${Math.round(p * 100)}%`;
      else if (cfg.text_format !== 'none') {
        text = formatClock(cfg.count_up ? elapsed : remaining, cfg.text_format, cfg.decimals);
      }
      view.update({ total: cfg.seconds, remaining, elapsed, p, phase, color, text, now });
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
  }

  return {
    set(next) {
      stop();
      cfg = next;
      container.innerHTML = '';
      view = createTimerView(cfg);
      container.appendChild(view.el);
      const scale = Math.min(1, 168 / Math.max(view.el.offsetWidth || cfg.size, cfg.size));
      container.style.setProperty('--preview-scale', scale.toFixed(3));
      t0 = performance.now();
      loop();
    },
    stop,
  };
}

export function createSettings(options) {
  const { panel, draft, onApply, onSave, onResetDefaults, pickImage, onCloseRequest } = options;

  const tabsEl = panel.querySelector('.settings-tabs');
  const pagesEl = panel.querySelector('.settings-pages');
  const statusEl = panel.querySelector('.settings-status');

  let currentPage = 'general';
  let selectedTimer = 0;
  let selectedTracker = 0;
  let selectedPanel = 0;
  let selectedPage = 0;
  let preview = null;
  let panelPreview = null;
  let panelPreviewTimer = null;

  const refreshPanels = () => {
    if (options.refreshPanels) options.refreshPanels();
  };

  function mountPreview(container, panel) {
    if (panelPreview) panelPreview.destroy();
    panelPreview = mountPanel(container, normalizePanel({ ...deepCopy(panel), opacity: 100, scale: 100 }),
      options.stats, { rotate: true });
  }

  // Rebuilding the preview on every slider step would thrash the DOM.
  function schedulePanelPreview(panel) {
    clearTimeout(panelPreviewTimer);
    panelPreviewTimer = setTimeout(() => {
      const box = pagesEl.querySelector('.panel-preview');
      if (box) mountPreview(box, panel);
    }, 160);
  }

  const capture = createHotkeyCapture({
    container: panel,
    onCommit: (target, value) => {
      if (target.startsWith('stat:')) {
        const [, id, field] = target.split(':');
        const tracker = draft.stats.trackers.find((t) => t.id === id);
        if (tracker) tracker[`hotkey_${field}`] = value;
      } else if (target.startsWith('timer:')) {
        const index = Number.parseInt(target.slice(6), 10);
        if (draft.countdowns[index]) draft.countdowns[index].hotkey = value;
      } else {
        draft.hotkeys[target] = value;
      }
      apply();
      flash(value ? `Atajo asignado: ${formatHotkey(value)}` : 'Atajo borrado');
    },
  });

  function flash(message) {
    statusEl.textContent = message;
    statusEl.classList.add('visible');
    clearTimeout(flash._t);
    flash._t = setTimeout(() => statusEl.classList.remove('visible'), 2200);
  }

  function apply() {
    onApply(draft);
  }

  // --- tabs -----------------------------------------------------------------

  function renderTabs() {
    tabsEl.innerHTML = '';
    for (const page of PAGES) {
      const button = el('button', 'settings-tab');
      button.type = 'button';
      button.dataset.page = page.id;
      button.append(el('span', 'tab-icon', page.icon), el('span', 'tab-label', page.label));
      button.setAttribute('aria-selected', String(page.id === currentPage));
      button.addEventListener('click', () => {
        currentPage = page.id;
        render();
      });
      tabsEl.appendChild(button);
    }
  }

  // --- pages ----------------------------------------------------------------

  function pageGeneral() {
    const ui = draft.interface;
    const page = el('div', 'settings-page');
    page.appendChild(group('Apariencia', [
      selectField('Tema', ui.theme, THEMES.concat([{ id: 'custom', label: 'Personalizado' }]), (v) => {
        ui.theme = v;
        const theme = THEMES.find((t) => t.id === v);
        if (theme) ui.accent_color = theme.accent;
        apply();
        render();
      }),
      colorField('Color de acento', ui.accent_color, (v) => {
        ui.accent_color = v;
        ui.theme = 'custom';
        apply();
      }),
      rangeField('Escala de la interfaz', ui.ui_scale, { min: 60, max: 200, suffix: '%' }, (v) => {
        ui.ui_scale = v;
        apply();
      }),
      rangeField('Opacidad de los paneles', ui.panel_opacity, { min: 50, max: 100, suffix: '%' }, (v) => {
        ui.panel_opacity = v;
        apply();
      }),
    ], { columns: 2 }));

    page.appendChild(group('Comportamiento', [
      toggleField('Barra de herramientas', ui.show_toolbar, (v) => {
        ui.show_toolbar = v;
        apply();
      }, 'Botones flotantes de bloqueo y ajustes'),
      selectField('Posición de la barra', ui.toolbar_position, [
        { id: 'bottom-right', label: 'Abajo derecha' },
        { id: 'bottom-left', label: 'Abajo izquierda' },
        { id: 'top-right', label: 'Arriba derecha' },
        { id: 'top-left', label: 'Arriba izquierda' },
      ], (v) => {
        ui.toolbar_position = v;
        apply();
      }),
      toggleField('Reducir animaciones', ui.reduce_motion, (v) => {
        ui.reduce_motion = v;
        apply();
      }, 'Menos movimiento y menos carga de GPU'),
      toggleField('Iniciar bloqueado', ui.start_locked, (v) => {
        ui.start_locked = v;
      }, 'Arranca en modo atravesable'),
    ], { columns: 2 }));

    const fit = options.getScreenFit ? options.getScreenFit() : null;
    const fitLine = el('div', 'field');
    fitLine.appendChild(el('label', 'field-label', 'Zona que cubre ahora mismo'));
    fitLine.appendChild(el('span', 'screen-readout', fit
      ? `${fit.width} × ${fit.height} px desde (${fit.x}, ${fit.y})`
      : 'Sin datos todavía'));
    fitLine.appendChild(el('span', 'field-hint', fit
      ? `${fit.monitors} ${fit.monitors === 1 ? 'pantalla detectada' : 'pantallas detectadas'} · escala ${Math.round(fit.scale * 100)}%`
      : 'Abre la app desde Windows para verlo'));

    page.appendChild(group('Pantalla', [
      selectField('Qué debe cubrir', ui.screen_mode, SCREEN_MODES, (v) => {
        ui.screen_mode = v;
        apply();
        if (options.onFitScreen) options.onFitScreen(v);
      }, (SCREEN_MODES.find((m) => m.id === ui.screen_mode) || {}).hint),
      fitLine,
      buttonRow([
        { label: 'Reajustar ahora', onClick: async () => {
          if (!options.onFitScreen) return;
          const result = await options.onFitScreen(ui.screen_mode);
          flash(result ? `Ajustado a ${result.width} × ${result.height}` : 'No se pudo reajustar');
          render();
        } },
      ]),
    ], {
      columns: 2,
      note: 'El overlay se estira sobre el rectángulo completo del monitor, incluida la franja de la barra de tareas. Si cambias de resolución se reajusta solo.',
    }));

    page.appendChild(group('Restablecer', [
      buttonRow([
        { label: 'Valores de fábrica', variant: 'danger', onClick: () => onResetDefaults() },
      ]),
    ]));
    return page;
  }

  function pageStopwatch() {
    const sw = draft.stopwatch;
    const page = el('div', 'settings-page');
    const set = (key) => (v) => {
      sw[key] = v;
      apply();
    };

    page.appendChild(group('Visualización', [
      toggleField('Mostrar cronómetro', sw.visible, set('visible')),
      selectField('Estilo', sw.style, STOPWATCH_STYLES, (v) => {
        sw.style = v;
        apply();
      }),
      selectField('Tipografía', sw.font_family, FONT_FAMILIES, set('font_family')),
      numberField('Tamaño', sw.font_size, { min: 16, max: 160, suffix: 'px' }, set('font_size')),
      rangeField('Grosor de la fuente', sw.font_weight, { min: 100, max: 900, step: 100 }, set('font_weight')),
      numberField('Espaciado', sw.letter_spacing, { min: -2, max: 16, suffix: 'px' }, set('letter_spacing')),
    ], { columns: 2 }));

    page.appendChild(group('Colores y fondo', [
      colorField('Color de los dígitos', sw.color, set('color')),
      colorField('Color de los separadores', sw.separator_color, set('separator_color')),
      rangeField('Brillo', sw.glow, { min: 0, max: 100, suffix: '%' }, set('glow')),
      rangeField('Opacidad del fondo', sw.backdrop_opacity, { min: 0, max: 100, suffix: '%' }, set('backdrop_opacity')),
      numberField('Radio de esquinas', sw.corner_radius, { min: 0, max: 40, suffix: 'px' }, set('corner_radius')),
      rangeField('Opacidad general', sw.opacity, { min: 10, max: 100, suffix: '%' }, set('opacity')),
    ], { columns: 2 }));

    page.appendChild(group('Formato', [
      toggleField('Mostrar horas', sw.show_hours, set('show_hours')),
      toggleField('Mostrar centésimas', sw.show_centiseconds, (v) => {
        sw.show_centiseconds = v;
        if (v) sw.show_milliseconds = false;
        apply();
        render();
      }),
      toggleField('Mostrar milésimas', sw.show_milliseconds, (v) => {
        sw.show_milliseconds = v;
        if (v) sw.show_centiseconds = false;
        apply();
        render();
      }),
      toggleField('Parpadeo de separadores', sw.blink_separator, set('blink_separator')),
    ], { columns: 2 }));

    page.appendChild(group('Extras', [
      toggleField('Botones visibles', sw.show_controls, set('show_controls')),
      toggleField('Texto de estado', sw.show_status, set('show_status')),
      toggleField('Lista de vueltas', sw.show_laps, set('show_laps')),
      numberField('Vueltas visibles', sw.lap_count, { min: 1, max: 10 }, set('lap_count')),
      toggleField('Anillo de progreso', sw.progress_ring, set('progress_ring')),
      numberField('Ciclo del anillo', sw.progress_minutes, { min: 1, max: 120, suffix: 'min' }, set('progress_minutes')),
    ], { columns: 2 }));

    page.appendChild(group('Posición', [
      selectField('Anclaje', sw.position, ANCHORS, set('position')),
      numberField('Desplazamiento X', sw.offset_x, { min: -4000, max: 4000, suffix: 'px' }, set('offset_x')),
      numberField('Desplazamiento Y', sw.offset_y, { min: -4000, max: 4000, suffix: 'px' }, set('offset_y')),
    ], { columns: 3 }));
    return page;
  }

  function pageCrosshair() {
    const ch = draft.crosshair;
    const page = el('div', 'settings-page');
    const set = (key) => (v) => {
      ch[key] = v;
      apply();
    };
    page.appendChild(group('Mira', [
      toggleField('Mostrar mira', ch.enabled, set('enabled')),
      selectField('Forma', ch.pointer_type, POINTER_TYPES, set('pointer_type')),
      colorField('Color', ch.color, set('color')),
      numberField('Longitud', ch.size, { min: 2, max: 120, suffix: 'px' }, set('size')),
      numberField('Grosor', ch.thickness, { min: 1, max: 16, suffix: 'px' }, set('thickness')),
      numberField('Separación central', ch.gap, { min: 0, max: 60, suffix: 'px' }, set('gap')),
      rangeField('Opacidad', ch.opacity, { min: 10, max: 100, suffix: '%' }, set('opacity')),
      numberField('Ajuste vertical', ch.offset_y, { min: -400, max: 400, suffix: 'px' }, set('offset_y')),
      toggleField('Contorno oscuro', ch.outline, set('outline')),
      toggleField('Punto central', ch.dot, set('dot')),
    ], { columns: 2 }));
    return page;
  }

  function pageScoreboard() {
    const sb = draft.scoreboard;
    const page = el('div', 'settings-page');
    const set = (key) => (v) => {
      sb[key] = v;
      apply();
    };
    page.appendChild(group('Marcador', [
      toggleField('Mostrar marcador', sb.visible, set('visible')),
      selectField('Estilo', sb.style, [
        { id: 'glass', label: 'Cristal' },
        { id: 'minimal', label: 'Mínimo' },
        { id: 'bars', label: 'Barras' },
        { id: 'cards', label: 'Tarjetas' },
      ], set('style')),
      textField('Jugador 1', sb.player1_name, { maxlength: 16 }, set('player1_name')),
      textField('Jugador 2', sb.player2_name, { maxlength: 16 }, set('player2_name')),
      colorField('Color jugador 1', sb.accent1, set('accent1')),
      colorField('Color jugador 2', sb.accent2, set('accent2')),
      numberField('Tamaño de los números', sb.font_size, { min: 14, max: 96, suffix: 'px' }, set('font_size')),
      toggleField('Mostrar título', sb.show_title, set('show_title')),
      rangeField('Opacidad', sb.opacity, { min: 10, max: 100, suffix: '%' }, set('opacity')),
    ], { columns: 2 }));

    page.appendChild(group('Posición', [
      selectField('Anclaje', sb.position, ANCHORS, set('position')),
      numberField('Desplazamiento X', sb.offset_x, { min: -4000, max: 4000, suffix: 'px' }, set('offset_x')),
      numberField('Desplazamiento Y', sb.offset_y, { min: -4000, max: 4000, suffix: 'px' }, set('offset_y')),
    ], { columns: 3 }));

    page.appendChild(group('Puntuación', [
      buttonRow([
        { label: 'Reiniciar marcador', variant: 'danger', onClick: () => {
          sb.player1_score = 0;
          sb.player2_score = 0;
          apply();
          flash('Marcador a cero');
        } },
      ]),
    ]));
    return page;
  }

  function pageHotkeys() {
    const page = el('div', 'settings-page');
    page.appendChild(group('Acciones globales', HOTKEY_ACTIONS.map((action) =>
      hotkeyField(action.label, action.id, draft.hotkeys[action.id], action.hint),
    ), { columns: 2, note: 'Haz clic en un atajo y pulsa la combinación. Supr o Retroceso lo borra, Esc cancela.' }));

    page.appendChild(group('Temporizadores', draft.countdowns.map((cd, i) =>
      hotkeyField(cd.label || `Temporizador ${i + 1}`, `timer:${i}`, cd.hotkey, `${cd.seconds}s · ${
        (TIMER_STYLES.find((s) => s.id === cd.style) || {}).label || cd.style}`),
    ), { columns: 2 }));
    return page;
  }

  function pageTimers() {
    const page = el('div', 'settings-page timers-page');
    const list = draft.countdowns;
    if (selectedTimer >= list.length) selectedTimer = Math.max(0, list.length - 1);

    const chips = el('div', 'timer-chips');
    list.forEach((cd, i) => {
      const chip = el('button', 'timer-chip');
      chip.type = 'button';
      chip.dataset.active = String(i === selectedTimer);
      chip.style.setProperty('--chip-color', cd.color);
      chip.append(
        el('span', 'chip-dot'),
        el('span', 'chip-name', cd.label || `Temporizador ${i + 1}`),
        el('span', 'chip-meta', `${cd.seconds}s`),
      );
      chip.addEventListener('click', () => {
        selectedTimer = i;
        render();
      });
      chips.appendChild(chip);
    });
    const add = el('button', 'timer-chip add');
    add.type = 'button';
    add.textContent = '+ Añadir';
    add.addEventListener('click', () => {
      if (list.length >= 24) return flash('Máximo de 24 temporizadores');
      list.push(normalizeTimer({ label: `Temporizador ${list.length + 1}`, seconds: 30 }));
      selectedTimer = list.length - 1;
      apply();
      render();
    });
    chips.appendChild(add);
    page.appendChild(chips);

    if (!list.length) {
      page.appendChild(el('p', 'empty-note', 'Añade un temporizador para empezar.'));
      return page;
    }

    const cd = list[selectedTimer];
    const set = (key) => (v) => {
      cd[key] = v;
      apply();
      if (preview) preview.set({ ...cd });
    };
    const setAndRebuild = (key) => (v) => {
      cd[key] = v;
      apply();
      render();
    };

    // Preview + presets header
    const head = el('div', 'timer-editor-head');
    const previewBox = el('div', 'timer-preview');
    const previewStage = el('div', 'timer-preview-stage');
    previewBox.append(el('span', 'timer-preview-label', 'Vista previa'), previewStage);
    head.appendChild(previewBox);

    const presets = el('div', 'timer-presets');
    presets.appendChild(el('span', 'field-label', 'Ajustes rápidos'));
    const presetRow = el('div', 'preset-row');
    for (const p of TIMER_PRESETS) {
      const b = el('button', 'chip-button', p.label);
      b.type = 'button';
      b.addEventListener('click', () => {
        Object.assign(cd, normalizeTimer({ ...cd, ...p.patch }));
        apply();
        render();
      });
      presetRow.appendChild(b);
    }
    presets.appendChild(presetRow);
    presets.appendChild(el('span', 'field-label', 'Acciones'));
    presets.appendChild(buttonRow([
      { label: 'Probar', onClick: () => options.onTest(selectedTimer) },
      { label: 'Duplicar', onClick: () => {
        if (list.length >= 24) return flash('Máximo de 24 temporizadores');
        list.splice(selectedTimer + 1, 0, normalizeTimer({ ...cd, hotkey: '', label: `${cd.label} copia` }));
        selectedTimer += 1;
        apply();
        render();
      } },
      { label: 'Eliminar', variant: 'danger', onClick: () => {
        list.splice(selectedTimer, 1);
        selectedTimer = Math.max(0, selectedTimer - 1);
        apply();
        render();
      } },
    ]));
    head.appendChild(presets);
    page.appendChild(head);

    page.appendChild(group('Identidad', [
      textField('Nombre', cd.label, { maxlength: 24 }, (v) => {
        cd.label = v;
        apply();
      }, 'Se muestra en la lista y, si quieres, bajo el temporizador'),
      hotkeyField('Atajo', `timer:${selectedTimer}`, cd.hotkey),
      numberField('Duración', cd.seconds, { min: 1, max: 86400, suffix: 's' }, setAndRebuild('seconds')),
      toggleField('Permitir varios a la vez', cd.allow_multiple, set('allow_multiple')),
    ], { columns: 2 }));

    page.appendChild(group('Estilo visual', [
      selectField('Diseño', cd.style, TIMER_STYLES.map((s) => ({ id: s.id, label: s.label, group: s.group })),
        setAndRebuild('style'), (TIMER_STYLES.find((s) => s.id === cd.style) || {}).hint),
      numberField('Tamaño', cd.size, { min: 48, max: 640, suffix: 'px' }, set('size')),
      numberField('Grosor de línea', cd.thickness, { min: 1, max: 40, step: 0.5, suffix: 'px' }, set('thickness')),
      numberField('Segmentos / marcas', cd.segments, { min: 2, max: 120 }, setAndRebuild('segments')),
      selectField('Sentido', cd.direction, [
        { id: 'drain', label: 'Se vacía' },
        { id: 'fill', label: 'Se llena' },
      ], setAndRebuild('direction')),
      selectField('Giro', cd.spin, [
        { id: 'cw', label: 'Horario' },
        { id: 'ccw', label: 'Antihorario' },
      ], setAndRebuild('spin')),
      numberField('Ángulo de inicio', cd.start_angle, { min: -360, max: 360, suffix: '°' }, setAndRebuild('start_angle')),
      rangeField('Opacidad', cd.opacity, { min: 10, max: 100, suffix: '%' }, set('opacity')),
    ], { columns: 2 }));

    page.appendChild(group('Colores', [
      colorField('Color principal', cd.color, set('color')),
      colorField('Color secundario', cd.color2, setAndRebuild('color2')),
      colorField('Color de la pista', cd.track_color, set('track_color')),
      rangeField('Opacidad de la pista', cd.track_opacity, { min: 0, max: 100, suffix: '%' }, set('track_opacity')),
      rangeField('Brillo', cd.glow, { min: 0, max: 100, suffix: '%' }, set('glow')),
    ], { columns: 2 }));

    page.appendChild(group('Texto', [
      selectField('Formato', cd.text_format, TEXT_FORMATS, setAndRebuild('text_format')),
      toggleField('Décimas de segundo', cd.decimals, set('decimals')),
      selectField('Tipografía', cd.font_family, FONT_FAMILIES, set('font_family')),
      rangeField('Tamaño del texto', cd.font_size, { min: 6, max: 60, suffix: '%' }, set('font_size')),
      rangeField('Grosor del texto', cd.font_weight, { min: 200, max: 900, step: 100 }, set('font_weight')),
      colorField('Color del texto', cd.text_color, set('text_color')),
      toggleField('Cuenta hacia arriba', cd.count_up, set('count_up')),
      toggleField('Mostrar nombre', cd.show_label, setAndRebuild('show_label')),
      selectField('Posición del nombre', cd.label_position, [
        { id: 'bottom', label: 'Debajo' },
        { id: 'top', label: 'Encima' },
      ], setAndRebuild('label_position')),
    ], { columns: 2 }));

    page.appendChild(group('Alertas', [
      numberField('Aviso a los', cd.warn_at, { min: 0, max: 3600, suffix: 's' }, set('warn_at')),
      numberField('Peligro a los', cd.danger_at, { min: 0, max: 3600, suffix: 's' }, set('danger_at')),
      colorField('Color de aviso', cd.warn_color, set('warn_color')),
      colorField('Color de peligro', cd.danger_color, set('danger_color')),
      toggleField('Latido al final', cd.pulse_on_danger, setAndRebuild('pulse_on_danger')),
      toggleField('Vibración al final', cd.shake_on_danger, setAndRebuild('shake_on_danger')),
      selectField('Sonido final', cd.sound, SOUNDS, set('sound')),
      rangeField('Volumen', cd.volume, { min: 0, max: 100, suffix: '%' }, set('volume')),
      toggleField('Tic en los últimos 3 s', cd.tick_sound, set('tick_sound')),
      selectField('Al terminar', cd.on_end, END_ACTIONS, set('on_end')),
    ], { columns: 2 }));

    const imageButtons = buttonRow([
      { label: cd.image ? 'Cambiar imagen' : 'Elegir imagen', onClick: () => {
        pickImage((dataUrl) => {
          cd.image = dataUrl;
          apply();
          render();
        });
      } },
      cd.image ? { label: 'Quitar', variant: 'danger', onClick: () => {
        cd.image = '';
        apply();
        render();
      } } : null,
    ].filter(Boolean));

    page.appendChild(group('Fondo e imagen', [
      selectField('Fondo', cd.backdrop, BACKDROPS, setAndRebuild('backdrop')),
      colorField('Color del fondo', cd.backdrop_color, set('backdrop_color')),
      rangeField('Opacidad del fondo', cd.backdrop_opacity, { min: 0, max: 100, suffix: '%' }, set('backdrop_opacity')),
      numberField('Radio de esquinas', cd.corner_radius, { min: 0, max: 80, suffix: 'px' }, set('corner_radius')),
      imageButtons,
      rangeField('Opacidad de la imagen', cd.image_opacity, { min: 0, max: 100, suffix: '%' }, set('image_opacity')),
      rangeField('Desenfoque de la imagen', cd.image_blur, { min: 0, max: 20, suffix: 'px' }, set('image_blur')),
    ], { columns: 2 }));

    page.appendChild(group('Posición', [
      selectField('Anclaje', cd.position, ANCHORS, setAndRebuild('position')),
      numberField('Desplazamiento X', cd.offset_x, { min: -2000, max: 2000, suffix: 'px' }, setAndRebuild('offset_x')),
      numberField('Desplazamiento Y', cd.offset_y, { min: -2000, max: 2000, suffix: 'px' }, setAndRebuild('offset_y')),
      selectField('Apilado', cd.stack, [
        { id: 'column', label: 'En columna' },
        { id: 'row', label: 'En fila' },
      ], setAndRebuild('stack')),
    ], { columns: 2 }));

    queueMicrotask(() => {
      if (preview) preview.stop();
      preview = createPreview(previewStage);
      preview.set({ ...cd });
    });

    return page;
  }

  // --- trackers -------------------------------------------------------------

  function trackerOptions(kind) {
    return draft.stats.trackers
      .filter((t) => !kind || t.kind === kind)
      .map((t) => ({ id: t.id, label: t.label }));
  }

  function applyTemplate(template) {
    const built = buildTemplate(template, draft.stats.trackers);
    if (draft.stats.trackers.length + built.trackers.length > 32) {
      return flash('Demasiados contadores');
    }
    draft.stats.trackers.push(...built.trackers);
    draft.stats.panels.push(...built.panels);
    selectedTracker = draft.stats.trackers.length - 1;
    selectedPanel = draft.stats.panels.length - 1;
    apply();
    render();
    flash(`Plantilla «${template.label}» añadida`);
  }

  function pageTrackers() {
    const list = draft.stats.trackers;
    const page = el('div', 'settings-page');

    page.appendChild(group('Plantillas listas', [
      buttonRow(STATS_TEMPLATES.map((t) => ({
        label: t.label,
        title: t.hint,
        onClick: () => applyTemplate(t),
      }))),
    ], { note: 'Cada plantilla crea los contadores y el panel ya montados y conectados. Después puedes retocarlo todo.' }));

    if (selectedTracker >= list.length) selectedTracker = Math.max(0, list.length - 1);

    const chips = el('div', 'stat-chip-row');
    list.forEach((t, i) => {
      const chip = el('button', 'stat-chip');
      chip.type = 'button';
      chip.dataset.active = String(i === selectedTracker);
      chip.style.setProperty('--chip-color', t.color);
      const value = t.kind === 'winloss' ? `${t.wins}-${t.losses}` : t.kind === 'text' ? '“…”' : String(t.value);
      chip.append(el('span', 'chip-dot'), el('span', 'chip-name', t.label), el('span', 'chip-meta', value));
      chip.addEventListener('click', () => {
        selectedTracker = i;
        render();
      });
      chips.appendChild(chip);
    });
    const add = el('button', 'stat-chip add');
    add.type = 'button';
    add.textContent = '+ Contador';
    add.addEventListener('click', () => {
      if (list.length >= 32) return flash('Máximo de 32 contadores');
      const taken = list.map((t) => t.key);
      list.push(normalizeTracker({ label: `Contador ${list.length + 1}` }, taken));
      selectedTracker = list.length - 1;
      apply();
      render();
    });
    chips.appendChild(add);
    page.appendChild(chips);

    if (!list.length) {
      page.appendChild(el('p', 'empty-note', 'Empieza con una plantilla o crea un contador vacío.'));
      return page;
    }

    const t = list[selectedTracker];
    const set = (key) => (v) => {
      t[key] = v;
      refreshPanels();
    };
    const setAndRebuild = (key) => (v) => {
      t[key] = v;
      apply();
      render();
    };

    const keyTag = el('div', 'field');
    keyTag.append(el('label', 'field-label', 'Clave para las fórmulas'), el('span', 'stat-key', t.key));
    keyTag.appendChild(el('span', 'field-hint', 'Úsala en fórmulas de los paneles'));

    page.appendChild(group('Identidad', [
      textField('Nombre', t.label, { maxlength: 28 }, set('label')),
      selectField('Tipo', t.kind, TRACKER_KINDS, setAndRebuild('kind'),
        (TRACKER_KINDS.find((k) => k.id === t.kind) || {}).hint),
      colorField('Color', t.color, set('color')),
      keyTag,
    ], { columns: 2 }));

    if (t.kind === 'winloss') {
      page.appendChild(group('Marcador del contador', [
        numberField('Victorias', t.wins, { min: 0, max: 99999 }, setAndRebuild('wins')),
        numberField('Derrotas', t.losses, { min: 0, max: 99999 }, setAndRebuild('losses')),
        numberField('Empates', t.draws, { min: 0, max: 99999 }, setAndRebuild('draws')),
        numberField('Mejor marca (a mano)', t.record, { min: 0, max: 999999 }, setAndRebuild('record'),
          'Para récords que no se calculan solos'),
        buttonRow([
          { label: 'Victoria', onClick: () => { options.stats.registerResult(t.id, 'win'); render(); } },
          { label: 'Derrota', onClick: () => { options.stats.registerResult(t.id, 'loss'); render(); } },
          { label: 'Empate', onClick: () => { options.stats.registerResult(t.id, 'draw'); render(); } },
          { label: 'Deshacer', onClick: () => { options.stats.undo(t.id); render(); } },
        ]),
      ], { columns: 2 }));
    } else if (t.kind === 'text') {
      page.appendChild(group('Contenido', [
        textField('Texto', t.text, { maxlength: 120, placeholder: 'Por ejemplo: 61 partidas — Otzdarva' }, set('text')),
      ]));
    } else {
      page.appendChild(group('Valor', [
        numberField('Valor actual', t.value, { min: t.min, max: t.max }, setAndRebuild('value')),
        numberField('Récord', t.record, { min: 0, max: 999999 }, setAndRebuild('record')),
        toggleField('Guardar el récord solo', t.track_record, set('track_record'),
          'Sube cuando el valor supera al récord anterior'),
        numberField('Paso del atajo', t.step, { min: 1, max: 1000 }, set('step')),
        numberField('Mínimo', t.min, { min: -99999, max: 99999 }, setAndRebuild('min')),
        numberField('Máximo', t.max, { min: 0, max: 999999 }, setAndRebuild('max')),
      ], { columns: 3 }));

      const winlossOptions = [{ id: '', label: 'Nada' }, ...trackerOptions('winloss')];
      page.appendChild(group('Racha automática', [
        selectField('Sube con la victoria de', t.bump_with, winlossOptions, setAndRebuild('bump_with')),
        selectField('Se pone a cero con la derrota de', t.reset_with, winlossOptions, setAndRebuild('reset_with')),
      ], {
        columns: 2,
        note: 'Conecta este contador a uno de victorias y derrotas: sube solo con cada victoria y se reinicia con cada derrota. Así funciona una racha.',
      }));
    }

    const isWl = t.kind === 'winloss';
    page.appendChild(group('Atajos', [
      hotkeyField(isWl ? 'Victoria' : 'Sumar', `stat:${t.id}:up`, t.hotkey_up),
      hotkeyField(isWl ? 'Derrota' : 'Restar', `stat:${t.id}:down`, t.hotkey_down),
      isWl ? hotkeyField('Empate', `stat:${t.id}:draw`, t.hotkey_draw) : null,
      isWl ? hotkeyField('Deshacer la última', `stat:${t.id}:undo`, t.hotkey_undo) : null,
      hotkeyField('Poner a cero', `stat:${t.id}:reset`, t.hotkey_reset),
    ].filter(Boolean), { columns: 2, note: 'Funcionan aunque el juego esté en primer plano.' }));

    page.appendChild(group('Sesión y acciones', [
      toggleField('Se reinicia con la sesión', t.reset_on_session, set('reset_on_session'),
        'El récord y el texto no se pierden'),
      buttonRow([
        { label: 'Poner a cero', onClick: () => { options.stats.reset(t.id); render(); } },
        { label: 'Borrar el récord', onClick: () => { options.stats.resetRecord(t.id); render(); } },
        { label: 'Eliminar contador', variant: 'danger', onClick: () => {
          draft.stats.trackers.splice(selectedTracker, 1);
          selectedTracker = Math.max(0, selectedTracker - 1);
          apply();
          render();
        } },
      ]),
    ], { columns: 2 }));

    return page;
  }

  // --- panels ---------------------------------------------------------------

  function itemCard(item, page, index, panel) {
    const card = el('div', 'item-card');
    const head = el('div', 'item-card-head');
    head.appendChild(el('span', 'item-card-title', `Dato ${index + 1}`));
    head.appendChild(buttonRow([
      index > 0 ? { label: '↑', title: 'Subir', onClick: () => {
        page.items.splice(index - 1, 0, page.items.splice(index, 1)[0]);
        apply();
        render();
      } } : null,
      index < page.items.length - 1 ? { label: '↓', title: 'Bajar', onClick: () => {
        page.items.splice(index + 1, 0, page.items.splice(index, 1)[0]);
        apply();
        render();
      } } : null,
      { label: '×', title: 'Quitar', variant: 'danger', onClick: () => {
        page.items.splice(index, 1);
        apply();
        render();
      } },
    ].filter(Boolean)));
    card.appendChild(head);

    const set = (key) => (v) => {
      item[key] = v;
      apply();
    };
    const setAndRebuild = (key) => (v) => {
      item[key] = v;
      apply();
      render();
    };

    const needsTracker = ['tracker', 'record', 'record_pair', 'winrate', 'goal', 'history'].includes(item.source);
    const kindFilter = item.source === 'winrate' || item.source === 'history' ? 'winloss' : null;
    const fields = [
      selectField('Qué muestra', item.source, ITEM_SOURCES, setAndRebuild('source'),
        (ITEM_SOURCES.find((s) => s.id === item.source) || {}).hint),
      needsTracker
        ? selectField('Contador', item.tracker_id,
          [{ id: '', label: 'Sin elegir' }, ...trackerOptions(kindFilter)], setAndRebuild('tracker_id'))
        : null,
      textField('Etiqueta', item.label, { maxlength: 28, placeholder: 'Automática' }, set('label')),
      selectField('Tamaño', item.emphasis, EMPHASIS, set('emphasis')),
    ];

    if (item.source === 'formula') {
      const keys = Object.keys(options.stats.values());
      const input = textField('Fórmula', item.formula, { maxlength: 160, placeholder: 'kills / partidas * 100' }, (v) => {
        item.formula = v;
        const node = input.querySelector('input');
        node.classList.toggle('invalid', !formulaIsValid(v, keys));
        apply();
      });
      fields.push(input);
      const help = el('div', 'field');
      help.appendChild(el('label', 'field-label', 'Claves disponibles'));
      const helpText = el('div', 'formula-help');
      helpText.innerHTML = draft.stats.trackers.map((t) => {
        if (t.kind === 'winloss') {
          return `<code>${t.key}</code> partidas · <code>${t.key}_v</code> victorias · <code>${t.key}_d</code> derrotas · <code>${t.key}_pct</code> %`;
        }
        return `<code>${t.key}</code> valor · <code>${t.key}_record</code> récord`;
      }).concat('<code>sesion</code> minutos en directo').join('<br>');
      help.appendChild(helpText);
      fields.push(help);
    }
    if (item.source === 'text') {
      fields.push(textField('Texto', item.text, { maxlength: 120 }, set('text')));
    }
    if (item.source === 'goal') {
      fields.push(numberField('Meta', item.goal, { min: 1, max: 99999 }, set('goal')));
    }
    if (item.source === 'history') {
      fields.push(numberField('Cuántas', item.history_count, { min: 3, max: 30 }, setAndRebuild('history_count')));
    }

    fields.push(
      numberField('Decimales', item.decimals, { min: 0, max: 3 }, set('decimals')),
      textField('Prefijo', item.prefix, { maxlength: 8 }, set('prefix')),
      textField('Sufijo', item.suffix, { maxlength: 8, placeholder: '%' }, set('suffix')),
      colorField('Color propio', item.color || panel.text_color, set('color')),
      toggleField('Mostrar etiqueta', item.show_label, setAndRebuild('show_label')),
    );

    const grid = el('div', 'field-grid cols-2');
    for (const f of fields) if (f) grid.appendChild(f);
    card.appendChild(grid);
    return card;
  }

  function pagePanels() {
    const list = draft.stats.panels;
    const page = el('div', 'settings-page');

    if (selectedPanel >= list.length) selectedPanel = Math.max(0, list.length - 1);

    const chips = el('div', 'stat-chip-row');
    list.forEach((p, i) => {
      const chip = el('button', 'stat-chip');
      chip.type = 'button';
      chip.dataset.active = String(i === selectedPanel);
      chip.style.setProperty('--chip-color', p.color);
      chip.append(
        el('span', 'chip-dot'),
        el('span', 'chip-name', p.label),
        el('span', 'chip-meta', p.pages.length > 1 ? `${p.pages.length} págs` : '1 pág'),
      );
      chip.addEventListener('click', () => {
        selectedPanel = i;
        selectedPage = 0;
        render();
      });
      chips.appendChild(chip);
    });
    const add = el('button', 'stat-chip add');
    add.type = 'button';
    add.textContent = '+ Panel';
    add.addEventListener('click', () => {
      if (list.length >= 16) return flash('Máximo de 16 paneles');
      list.push(normalizePanel({ label: `Panel ${list.length + 1}` }));
      selectedPanel = list.length - 1;
      selectedPage = 0;
      apply();
      render();
    });
    chips.appendChild(add);
    page.appendChild(chips);

    if (!list.length) {
      page.appendChild(el('p', 'empty-note',
        'Todavía no hay paneles. Crea uno aquí o usa una plantilla en la pestaña Contadores.'));
      return page;
    }

    const p = list[selectedPanel];
    if (selectedPage >= p.pages.length) selectedPage = 0;

    const set = (key) => (v) => {
      p[key] = v;
      apply();
      schedulePanelPreview(p);
    };
    const setAndRebuild = (key) => (v) => {
      p[key] = v;
      apply();
      render();
    };

    const previewBox = el('div', 'panel-preview');
    page.appendChild(previewBox);

    page.appendChild(group('Panel', [
      textField('Nombre', p.label, { maxlength: 28 }, (v) => {
        p.label = v;
        apply();
      }),
      toggleField('Visible', p.visible, setAndRebuild('visible')),
      selectField('Estilo', p.style, PANEL_STYLES, set('style'),
        (PANEL_STYLES.find((s) => s.id === p.style) || {}).hint),
      selectField('Disposición', p.layout, PANEL_LAYOUTS, set('layout')),
      selectField('Anclaje', p.position, ANCHORS, setAndRebuild('position')),
      numberField('Desplazamiento X', p.offset_x, { min: -4000, max: 4000, suffix: 'px' }, setAndRebuild('offset_x')),
      numberField('Desplazamiento Y', p.offset_y, { min: -4000, max: 4000, suffix: 'px' }, setAndRebuild('offset_y')),
      numberField('Ancho fijo', p.width, { min: 0, max: 1600, suffix: 'px' }, set('width'), '0 = se ajusta al contenido'),
      rangeField('Escala', p.scale, { min: 40, max: 250, suffix: '%' }, set('scale')),
      rangeField('Opacidad', p.opacity, { min: 10, max: 100, suffix: '%' }, set('opacity')),
    ], { columns: 3 }));

    page.appendChild(group('Rotación automática', [
      numberField('Cambiar de página cada', p.rotate_seconds, { min: 0, max: 600, suffix: 's' }, set('rotate_seconds'),
        '0 deja fija la primera página'),
      selectField('Transición', p.transition, PANEL_TRANSITIONS, set('transition')),
      toggleField('Puntos de página', p.show_page_dots, set('show_page_dots')),
    ], {
      columns: 3,
      note: 'Con dos o más páginas, el panel va enseñando una tras otra. El atajo «Pasar de página» las adelanta a mano.',
    }));

    page.appendChild(group('Colores y tipografía', [
      colorField('Acento', p.color, set('color')),
      colorField('Color de los valores', p.text_color, set('text_color')),
      colorField('Color de las etiquetas', p.label_color, set('label_color')),
      colorField('Color del fondo', p.backdrop_color, set('backdrop_color')),
      rangeField('Opacidad del fondo', p.backdrop_opacity, { min: 0, max: 100, suffix: '%' }, set('backdrop_opacity')),
      rangeField('Brillo', p.glow, { min: 0, max: 100, suffix: '%' }, set('glow')),
      numberField('Radio de esquinas', p.corner_radius, { min: 0, max: 40, suffix: 'px' }, set('corner_radius')),
      toggleField('Borde', p.border, set('border')),
      selectField('Tipografía', p.font_family, FONT_FAMILIES, set('font_family')),
      numberField('Tamaño del título', p.title_size, { min: 8, max: 40, suffix: 'px' }, set('title_size')),
      numberField('Tamaño de etiquetas', p.label_size, { min: 8, max: 40, suffix: 'px' }, set('label_size')),
      numberField('Tamaño de valores', p.value_size, { min: 10, max: 120, suffix: 'px' }, set('value_size')),
      toggleField('Mostrar títulos', p.show_title, set('show_title')),
      toggleField('Etiquetas en mayúsculas', p.uppercase_labels, set('uppercase_labels')),
    ], { columns: 3 }));

    // --- pages of this panel
    const tabs = el('div', 'page-tabs');
    p.pages.forEach((pg, i) => {
      const tab = el('button', 'page-tab', pg.title || `Página ${i + 1}`);
      tab.type = 'button';
      tab.dataset.active = String(i === selectedPage);
      tab.addEventListener('click', () => {
        selectedPage = i;
        render();
      });
      tabs.appendChild(tab);
    });
    const addPage = el('button', 'page-tab add', '+ Página');
    addPage.type = 'button';
    addPage.addEventListener('click', () => {
      if (p.pages.length >= 12) return flash('Máximo de 12 páginas');
      p.pages.push({ title: `Página ${p.pages.length + 1}`, items: [] });
      selectedPage = p.pages.length - 1;
      if (!p.rotate_seconds) p.rotate_seconds = 8;
      apply();
      render();
    });
    tabs.appendChild(addPage);

    const current = p.pages[selectedPage];
    const pageBox = el('section', 'field-group');
    pageBox.appendChild(el('h4', 'field-group-title', 'Páginas'));
    pageBox.appendChild(tabs);
    const pageGrid = el('div', 'field-grid cols-2');
    pageGrid.style.marginTop = '12px';
    pageGrid.appendChild(textField('Título de la página', current.title, { maxlength: 32 }, (v) => {
      current.title = v;
      apply();
      schedulePanelPreview(p);
    }));
    pageGrid.appendChild(buttonRow([
      { label: '+ Añadir dato', onClick: () => {
        if (current.items.length >= 10) return flash('Máximo de 10 datos por página');
        current.items.push({ ...DEFAULT_PANEL_ITEM });
        apply();
        render();
      } },
      p.pages.length > 1 ? { label: 'Eliminar página', variant: 'danger', onClick: () => {
        p.pages.splice(selectedPage, 1);
        selectedPage = Math.max(0, selectedPage - 1);
        apply();
        render();
      } } : null,
    ].filter(Boolean)));
    pageBox.appendChild(pageGrid);
    page.appendChild(pageBox);

    for (let i = 0; i < current.items.length; i++) {
      page.appendChild(itemCard(current.items[i], current, i, p));
    }
    if (!current.items.length) {
      page.appendChild(el('p', 'empty-note', 'Esta página está vacía. Añade un dato arriba.'));
    }

    page.appendChild(group('Acciones', [
      buttonRow([
        { label: 'Duplicar panel', onClick: () => {
          if (list.length >= 16) return flash('Máximo de 16 paneles');
          list.splice(selectedPanel + 1, 0, normalizePanel({ ...deepCopy(p), id: '', label: `${p.label} copia` }));
          selectedPanel += 1;
          apply();
          render();
        } },
        { label: 'Eliminar panel', variant: 'danger', onClick: () => {
          list.splice(selectedPanel, 1);
          selectedPanel = Math.max(0, selectedPanel - 1);
          apply();
          render();
        } },
      ]),
    ]));

    queueMicrotask(() => mountPreview(previewBox, p));
    return page;
  }

  const BUILDERS = {
    general: pageGeneral,
    trackers: pageTrackers,
    panels: pagePanels,
    timers: pageTimers,
    stopwatch: pageStopwatch,
    crosshair: pageCrosshair,
    scoreboard: pageScoreboard,
    hotkeys: pageHotkeys,
  };

  function render() {
    capture.cancel();
    if (preview) {
      preview.stop();
      preview = null;
    }
    if (panelPreview) {
      panelPreview.destroy();
      panelPreview = null;
    }
    clearTimeout(panelPreviewTimer);
    renderTabs();
    pagesEl.innerHTML = '';
    pagesEl.appendChild((BUILDERS[currentPage] || pageGeneral)());
    pagesEl.scrollTop = 0;
  }

  panel.querySelector('.settings-close').addEventListener('click', () => onCloseRequest());
  panel.querySelector('.settings-save').addEventListener('click', async () => {
    const button = panel.querySelector('.settings-save');
    button.disabled = true;
    button.textContent = 'Guardando…';
    try {
      await onSave();
      flash('Ajustes guardados');
    } catch (error) {
      flash('No se pudo guardar');
      console.error(error);
    } finally {
      button.disabled = false;
      button.textContent = 'Guardar';
    }
  });

  return {
    render,
    goTo(page) {
      currentPage = page;
      render();
    },
    stopPreview() {
      if (preview) preview.stop();
      preview = null;
      if (panelPreview) panelPreview.destroy();
      panelPreview = null;
      clearTimeout(panelPreviewTimer);
    },
    flash,
  };
}
